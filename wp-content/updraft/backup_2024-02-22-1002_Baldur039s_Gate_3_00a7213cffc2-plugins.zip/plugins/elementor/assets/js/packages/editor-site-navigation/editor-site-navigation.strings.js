__( 'Pages', 'elementor' );
__( 'Page', 'elementor' );
__( 'Pages', 'elementor' );
__( 'Recent', 'elementor' );
__( 'There are no other pages or templates on this site yet.', 'elementor' );
__( 'Add new page', 'elementor' );
__( 'Pages', 'elementor' );
__( 'Add New', 'elementor' );
__( 'Homepage', 'elementor' );
__( 'copy', 'elementor' );
__( 'New Page', 'elementor' );
__( 'Name is required', 'elementor' );
// translators: %s: Post type (e.g. Page, Post, etc.)
__( 'View %s', 'elementor' );
__( 'Set as homepage', 'elementor' );
__( 'Rename', 'elementor' );
__( 'Duplicate', 'elementor' );
__( 'Delete', 'elementor' );
/* translators: %s: Post title. */
__( 'Delete "%s"?', 'elementor' );
__( 'The page and its content will be deleted forever and we won’t be able to recover them.', 'elementor' );
__( 'Cancel', 'elementor' );
__( 'Delete', 'elementor' );